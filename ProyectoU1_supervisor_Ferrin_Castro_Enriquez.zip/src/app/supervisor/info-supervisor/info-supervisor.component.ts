import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-info-supervisor',
  templateUrl: './info-supervisor.component.html',
  styleUrls: ['./info-supervisor.component.scss']
})
export class InfoSupervisorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
