import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registrar-tecnico',
  templateUrl: './registrar-tecnico.component.html',
  styleUrls: ['./registrar-tecnico.component.scss']
})
export class RegistrarTecnicoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
